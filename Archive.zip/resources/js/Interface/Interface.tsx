export interface Applicant {
  category: string
  name: string
  id_card_number: string
  sex: string
  religion: string
  phone: string
  email: string
  district: string
  ward: string
  description: string
  id?: number
  file_id_card?: string | null | File
  file_family_card?: string | null | File
  file_lost_letter?: string | null | File
  images: string | File | undefined
  status?: string
  status_description?: string | null
}

export interface District {
  id: number
  name: string
}

export interface Ward {
  id: number
  district_id: number
  name: string
}

export const persyaratan: Map<String, String[]> = new Map<String, String[]>([
  ['KTP-Pemula', ['KK terbaru']],
  ['KTP-Rusak', [
    'KTP-el (rusak)',
    'KK Asli (Pada saat pengambilan KTP-el lampirkan Fotocopy KK)'
  ]],
  ['KTP-Perubahan', [
    'KTP-el asli',
    'KK Asli (Pada saat pengambilan KTP-el lampirkan Fotocopy KK)',
    'Catatan : ',
    'KTP lama wajib diserahkan pada saat pengambilan dokumen'
  ]],
  ['KTP-Hilang', [
    'Foto copy KTP-el (jika masih ada)',
    'KK Asli (Pada saat pengambilan KTP-el lampirkan Fotocopy KK)',
    'Surat keterangan hilang dari kepolisian',
  ]],
  ['KTP-Disabilitas', [
    'KTP-el asli',
    'KK Asli (Pada saat pengambilan KTP-el lampirkan Fotocopy KK)',
    'Catatan : ',
    'KTP lama wajib diserahkan pada saat pengambilan dokumen'
  ]],
])
