export const defImage = 'https://www.chanchao.com.tw/images/default.jpg'
