<?php

return [
  'configs' => [
    'default' => [
        'entrypoints' => [
            'paths' => [
                'resources/js/app.tsx',
            ],
        ],
    ],
  ],
];
